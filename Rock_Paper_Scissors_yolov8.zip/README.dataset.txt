# Rock Paper Scissors > Rock-Paper-Scissors_raw-images
https://universe.roboflow.com/team-roboflow/rock-paper-scissors-detection

Provided by a Roboflow user
License: undefined

Kaylee from Team Roboflow demos how to train a rock paper scissors object detector with this dataset.

Try it out on your Webcam! And remember, if it doesn't work so well, to make it better, you can upload and annotate new images of yourself doing rock paper scissors to futher educate the model.

